# Dynamics Performance Inspector v4.1.2

Runtime performance investigation for Microsoft Dynamics 365 and Dataverse model-driven apps.

## What was improved

### Session / lifecycle
- One global investigation session instead of one session per tab.
- Session survives side-panel close/reopen and Dynamics page reloads within the browser session.
- Cross-tab capture and automatic re-injection after supported Dynamics navigation/reload.
- Explicit page and navigation identities so events can be traced across a journey.

### Runtime evidence
- UI action capture with action IDs.
- Dataverse Web API timing with API IDs and caller stacks.
- Fetch/XHR/beacon timing with request IDs.
- Timing-based API ↔ network correlation.
- Script resource timing and long-task evidence.
- Runtime error capture and status evidence.

### Analysis
- Slow operation ranking.
- Duplicate request pattern detection.
- Sequential/overlapping API chain detection.
- Estimated critical-path analysis.
- Root-cause-oriented findings and recommendations.
- Analysis integrity indicators and dropped-event count.

### UX
- Live search, filter and sorting.
- New-event indicator when the investigator scrolls away from the live edge.
- Timeline, Analysis, JavaScript, API/Network, Diagnostics, Session and Report views.
- Event details include page/navigation/action/API/network identifiers.

### Privacy
- Local analysis by default.
- Request bodies and sensitive headers are not stored.
- Obvious GUID, email and token patterns are sanitized before storage/export.
- No telemetry or external endpoints.

## Important boundary

The JavaScript view uses resource timing, caller-stack evidence and long-task measurements. It is not a full CPU profiler. Server-side Dataverse plug-in execution time is not directly measurable from the browser extension; use Dataverse plug-in trace data separately for that layer.

## Installation

Load the unpacked extension directory in Chrome/Edge developer mode, or package the contents of this folder for store submission.


## 4.1.2 UI layout
- Data-first Side Panel layout optimized for narrow Chrome/Edge panels.
- Live Monitor feed receives the majority of the available viewport height.
- Only the event feed scrolls on the Live tab; header, filters, search and stats remain visible.
- Responsive controls adapt to narrow/wide side-panel widths without forcing horizontal page scroll.
- Focus mode remains available for maximum data density.
