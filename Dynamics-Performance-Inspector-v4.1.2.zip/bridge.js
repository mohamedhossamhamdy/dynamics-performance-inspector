(()=>{
  if(window.__DPI_BRIDGE_V41)return;
  window.__DPI_BRIDGE_V41=true;
  const send=p=>{try{chrome.runtime.sendMessage({kind:"PAGE_EVENT",payload:p})}catch{}};
  window.addEventListener("message",e=>{if(e.source!==window)return;const m=e.data;if(!m||m.source!=="DPI_V41")return;send(m.payload||m)},false);
  send({source:"DPI",type:"BRIDGE_READY",data:{version:"4.1.1"},ts:Date.now()});
  send({source:"DPI",type:"PAGE_READY",data:{href:location.href,title:document.title},ts:Date.now(),pageId:window.__DPI_PAGE_ID||null});
})();
